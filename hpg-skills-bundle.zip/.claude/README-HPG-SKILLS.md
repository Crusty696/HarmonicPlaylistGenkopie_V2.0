# HPG Experten-Skills — Installation & Überblick

Erstellt: 2026-07-24 · Zugeschnitten auf: HarmonicPlaylistGenkopie_V2.0-main

## Was ist enthalten

| Skill | Zweck |
|---|---|
| **hpg-mix-points** | Mix-In/Mix-Out-Punkte wie ein echter DJ: 3 Berechnungs-Pfade, Quantisierungs-Regeln, 9 dokumentierte Schwachstellen (B1-B8, E3) mit Fix-Patterns und Zeilennummern |
| **hpg-phrase-engine** | Phrasing (8/16/32 Bars): Phrasen-Phase-Schätzung (fehlt im Projekt!), phrase_unit-Messung, Section-Detection-Verbesserungen (A1-A3, E1-E4) |
| **hpg-harmonic-mixing** | Key-Detection + Camelot-Scoring: komplette Scoring-Tabelle, Confidence-Weighting, Stretch-Key-Kopplung, Energy-Boost-Regeln |
| **hpg-transition-quality** | Übergänge & Set-Dramaturgie: Scoring-Gewichte, Render-Pipeline (Equal-Power, Beat/Phrasen-Alignment), Vocal-Clash, Energy Arc (C1-C5, D1-D6) |
| **hpg-sota-updater** | Auto-Update: recherchiert neue Forschung/Tools (ISMIR, MIREX, Hugging Face) und schreibt die sota.md-Referenzen aller Skills fort; prüft Code-Drift der Landkarten |
| **agents/hpg-dj-expert.md** | Subagent-Definition für Claude Code (`.claude/agents/`) — arbeitet nach diesen Skills |

## Auto-Update-Mechanismus

Jedes Fach-Skill trägt `references/sota.md` mit `last_updated`-Datum und eigenen Such-Anweisungen. Beim Verwenden prüft das Skill selbst, ob es älter als 30 Tage ist, und aktualisiert sich dann per Web-Recherche. Zusätzlich kann `hpg-sota-updater` jederzeit alle vier auf einmal auffrischen ("bringe die HPG-Skills auf den neusten Stand"). Tipp: In Cowork lässt sich dafür auch eine monatliche geplante Aufgabe einrichten.

## Installation

**Variante A — Projekt-Skills für Claude Code (empfohlen, bereits erledigt wenn `.claude/skills/` im Repo existiert):** Die Skill-Ordner liegen in `<Repo>/.claude/skills/`, der Agent in `<Repo>/.claude/agents/`. Claude Code lädt sie automatisch in jeder Session in diesem Repo.

**Variante B — Account-Skills (für Cowork/Claude.ai):** Die `.skill`-Dateien aus dem Chat öffnen und auf "Skill speichern" klicken — dann stehen sie in allen Sessions zur Verfügung.

## Empfohlene Arbeitsreihenfolge (aus der Analyse vom 2026-07-24)

1. Phrasen-Phase implementieren (`hpg-phrase-engine`, Rezept 1) — Fundament für alles
2. Paar-Mix-Punkte quantisieren (`hpg-mix-points`, Pattern 1 / B1) — größter hörbarer Einzelgewinn
3. Renderer-Alignment auf Takt/Phrase + Equal-Power (`hpg-transition-quality`, 1-3)
4. Bass-Präsenz in die Mix-Punkt-Wahl (`hpg-mix-points`, Pattern 3 / B6)
5. Vocal-Clash + Texture ins Scoring (`hpg-transition-quality`, 4+7)
6. Key-Confidence ins Harmonic-Scoring (`hpg-harmonic-mixing`, Pattern 1)
