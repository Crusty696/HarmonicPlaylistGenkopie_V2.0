# Code-Landkarte: Mix-Points in HPG V2.0

Stand der Analyse: 2026-07-24 (Zeilennummern können nach Edits driften — bei Abweichung per Grep nach Funktionsnamen suchen).

## Datenfluss

```
analysis.analyze_track()
  ├─ Rekordbox-Cues?  → analysis.py:1029-1104 (Regex MIX-IN/MIX-OUT, Dedup <2s, min 3 Cues)
  │    └─ dj_brain.align_ai_mix_points()  (dj_brain.py:662-698, 2-Stufen-Grid)
  ├─ Sections vorhanden → dj_brain.calculate_genre_aware_mix_points()  (dj_brain.py:106-189)
  └─ Fallback → analysis.analyze_structure_and_mix_points()  (analysis.py:685-823, RMS)
                 └─ delegiert an calculate_genre_aware_mix_points()

playlist.compute_transition_recommendations()  (playlist.py:1262-1273)
  └─ dj_brain.calculate_paired_mix_points()  (dj_brain.py:553-659)
       → ÜBERSCHREIBT current_mix_out / next_mix_in / overlap  ← DAS wird gerendert!
```

## Kernfunktionen

### `calculate_genre_aware_mix_points(sections, bpm, duration, genre, anchor=0.0)` — dj_brain.py:106-189
- Rückgabe `(mix_in_time, mix_out_time, mix_in_bars, mix_out_bars)`
- `profile = get_mix_profile(genre)` → `GenreMixProfile` (genres.py:301-404)
- `grid_seconds = seconds_per_bar * profile.phrase_unit`
- `quantize_to_grid(mix_in, grid, anchor, "ceil")` / `(mix_out, grid, anchor, "floor")` (Z. 141-144)
- Clamps (Z. 149-183): `min_mix_in = max(intro_end, anchor + grid)`, `max_mix_out = min(outro_start, duration - grid)`, `min_window = grid * 2`, Notfall `0.15/0.85 * duration`
- `mix_in_bars = seconds_to_bars(t, bpm)` zählt ab t=0, NICHT ab anchor (models.py:168-173, dokumentiert)

### `_find_mix_in_point` — dj_brain.py:192-251
- Kandidaten: `start_time >= intro_end`, Label nicht intro/outro
- `label_priority = {"build":0, "main":1, "breakdown":2, "drop":3}`
- Key: `(prio, abs(avg_energy - avg_track_energy*0.75))` — KEIN Positionsterm!

### `_find_mix_out_point` — dj_brain.py:254-314
- Kandidaten: `end_time <= outro_start`, Label nicht intro/outro
- `label_priority = {"main":0, "breakdown":1, "build":2, "drop":3}`, Key `(prio, -end_time)` — Label schlägt Position!

### `calculate_paired_mix_points(track_a, track_b)` — dj_brain.py:553-659
- `min_overlap_bars = max(8, profile_b.transition_bars[0])`
- `target_overlap = max(min_overlap, min(intro_end_b, outro_duration_a))`, Cap `min(dur_a, dur_b)*0.5`
- `adjusted_mix_in_b = max(0, intro_end_b - target_overlap)` — UNQUANTISIERT (Z. 608)
- `adjusted_mix_out_a = max(outro_start_a, duration_a - target_overlap)` — UNQUANTISIERT (Z. 611)
- Guards Z. 623-651 quantisieren NUR, wenn der Punkt in Intro/Outro fällt

### `analysis.analyze_structure_and_mix_points` — analysis.py:685-823
- RMS (`librosa.feature.rms`, hop=HOP_LENGTH), Glättung 4-Takt-Fenster
- aktiv = `rms >= rms_max * RMS_THRESHOLD (0.4)` (Zehren et al.)
- Suchfenster: `MIX_IN_SEARCH_WINDOW_PCT=0.20`, `MIX_OUT_SEARCH_WINDOW_PCT=0.75`
- `fallback_len = seconds_per_bar * 16`
- baut 3 Pseudo-Sections intro/main/outro → delegiert an Pfad 1

### `models.quantize_to_grid(t, grid, anchor, mode)` — models.py:25-45
Einzige Quantisierungsfunktion. Modi "ceil"/"floor"/"round". Anker-relativ.

### `_get_intro_end_from_sections` — dj_brain.py:520-528
BUG-VERDACHT: bricht nur ab wenn `last_intro_end > 0`; Tail-Fenster-"intro" (analysis.py:873-880) kann intro_end ans Track-Ende ziehen.

## Konstanten (config.py)

| Konstante | Wert |
|---|---|
| HOP_LENGTH | 1024 |
| METER | 4 |
| MAX_TRANSITION_OVERLAP_SECONDS | 64.0 |
| MIX_IN_SEARCH_WINDOW_PCT | 0.20 |
| MIX_OUT_SEARCH_WINDOW_PCT | 0.75 |
| RMS_THRESHOLD | 0.4 |
| BARS_PER_PHRASE | 8 (TOTER CODE — phrase_unit kommt aus Genre-Profil) |
| LIBROSA_TAIL_DURATION | 180 s |

## Track-Felder (models.py:134-213), mix-relevant

`mix_in_point`, `mix_out_point` (Sekunden) · `mix_in_bars`, `mix_out_bars` (ab t=0!) · `first_downbeat`, `downbeat_confidence` (1.0 = Rekordbox-Beatgrid) · `phrase_unit` (Genre-Konstante, kein Messwert) · `sections` (list[dict], Labels intro/build/drop/breakdown/outro/main + nachträglich injiziert: avg_bass/avg_mids/avg_highs/percussive_ratio/analysis_status) · `outro_covered` (Mix-Out nur gültig wenn True — wird derzeit NICHT geprüft)

## Schwachstellen (Kurzliste, Details siehe SKILL.md)

- **B1** Paar-Mix-Punkte unquantisiert (dj_brain.py:608,611) — und genau die werden gerendert
- **B2** Overlap-Logik für B toter Code (Guard Z. 625-629 greift praktisch immer)
- **B3** `_dynamic_transition_bars` (932-970) wird von `overlap_seconds = duration - adjusted_mix_out_a` (Z. 418) + playlist.py:1271-1273 überschrieben
- **B4** Mix-In ohne Positionsterm → kann in 2. Trackhälfte landen
- **B5** Mix-Out: Label schlägt Position → kann bei 50 % landen
- **B6** avg_bass pro Section entsteht NACH Mix-Punkt-Wahl (analysis.py:1187-1204/1419-1421 vs. 1010-1027/1375-1381)
- **B7** intro_end-Scan-Bug (dj_brain.py:520-528)
- **B8** mix_*_bars ignorieren Anker (Anzeige irreführend)
- **E3** "unanalysed"-Sections wählbar, `outro_covered` ungeprüft
