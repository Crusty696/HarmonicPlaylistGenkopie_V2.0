# State of the Art: Cue-/Mix-Point-Detection

last_updated: 2026-07-24
update_interval_days: 30

## Auto-Update-Anweisung

Wenn `last_updated` älter als `update_interval_days` ist: Führe Web-Suchen durch mit
"automatic cue point detection DJ mixing <aktuelles Jahr>", "music structure analysis mix point electronic dance music", "switch point detection EDM". Aktualisiere diese Datei (neue Paper/Tools ergänzen, Überholtes markieren, `last_updated` setzen). Fasse dem User in 2-3 Sätzen zusammen, was neu ist.

## Referenz-Forschung (Stand Juli 2026)

- **Zehren, Alunno, Bientinesi — "Automatic Detection of Cue Points for the Emulation of DJ Mixing"** (Computer Music Journal 46(3), 2022): RMS-basierte Cue-Auswahl mit Schwelle 0.4·max — bereits Grundlage von `RMS_THRESHOLD` in HPG. Kernidee: Cue-Points liegen auf strukturellen Grenzen mit Low-Energy→High-Energy-Übergang. https://direct.mit.edu/comj/article/46/3/67/117159
- **Signals 5(4), 2024 — "Interpretability of Methods for Switch Point Detection in Electronic Dance Music"**: Vergleich von Switch-Point-Detektoren, betont Downbeat-/Phrasen-Alignment als dominanten Qualitätsfaktor. https://doi.org/10.3390/signals5040036
- **Vande Veire & De Bie (EURASIP 2018)** — "From raw audio to a seamless mix": Drum-and-Bass-Auto-DJ; Quelle der Downbeat-Heuristik in `downbeat.py` und des 16-Bar-Fallbacks.
- **Bittner et al. (Spotify, ISMIR 2017)** — Automatic Playlist Sequencing & Transitions; Quelle der 20 %/75 %-Suchfenster in HPG.
- **DJ AI (Audio Mostly 2025)** — Playlist-Alignment + Transition-Generierung mit Embedding-Modellen: https://dl.acm.org/doi/full/10.1145/3771594.3771640

## Tooling-Optionen (für optionale Upgrades)

- **allin1 (mir-aidj/all-in-one, arXiv:2307.16425)**: Beats, Downbeats, funktionale Segmente (intro/drop/break...) in einem Modell, auf demixtem Audio. Kandidat, um Section-Labels + Downbeats gleichzeitig zu verbessern. PyPI: `allin1` (Fork-Fix: `all-in-one-fix`). GPU empfohlen.
- **Beat This! (CPJKU, ISMIR 2024)**: Beat/Downbeat-Tracking ohne DBN-Postprocessing, robust genre-übergreifend, PyTorch. Bessere `first_downbeat`-Confidence als die Eigen-Heuristik. https://github.com/CPJKU/beat_this
- **madmom DBNDownbeatTrackingProcessor**: klassischer starker Baseline-Downbeat-Tracker (Achtung: numpy<2- und Python-3.11-Patches nötig).

## Übertrag auf HPG

Priorität ist NICHT ein Modellwechsel, sondern: (1) Phrasen-Phase korrekt bestimmen, (2) alle real gerenderten Punkte quantisieren, (3) Bass-Präsenz als Feature in die Punkt-Wahl. Erst danach lohnt ein allin1/Beat-This-Upgrade als optionaler Analyse-Backend.
