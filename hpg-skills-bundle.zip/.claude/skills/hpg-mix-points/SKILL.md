---
name: hpg-mix-points
description: Experten-Skill für Mix-In/Mix-Out-Punkt-Berechnung im HPG Harmonic Playlist Generator V2.0. IMMER verwenden bei Arbeit an Mix-Points, Cue-Points, mix_in_point/mix_out_point, calculate_genre_aware_mix_points, calculate_paired_mix_points, _find_mix_in_point/_find_mix_out_point, Übergangs-Fenstern (Overlap), Intro/Outro-Erkennung für Mixing, oder wenn der User sagt "der Mix startet an der falschen Stelle", "Mix-Punkt sitzt nicht", "Übergang beginnt zu früh/spät". Enthält die exakte Code-Landkarte (dj_brain.py, analysis.py, config.py), alle bekannten Schwachstellen mit Zeilennummern und die DJ-korrekten Fix-Patterns.
---

# HPG Mix-Points Expert

Dieses Skill macht dich zum Experten für die Mix-Punkt-Logik von HPG V2.0. Ziel: Mix-In/Out-Punkte, die ein echter DJ genauso setzen würde — auf der Phrasengrenze, wenn die Kick läuft (Mix-Out) bzw. bevor sie einsetzt (Mix-In), niemals mitten in einer Phrase oder in einem Vocal.

## Bevor du irgendetwas änderst

1. Lies `references/project-map.md` — die exakte Code-Landkarte (Funktionen, Konstanten, Datenfluss, Zeilennummern). Ohne sie wirst du Änderungen an der falschen Stelle machen: Es gibt DREI Pfade, die Mix-Punkte erzeugen, und der am sorgfältigsten quantisierte davon wird zur Laufzeit überschrieben.
2. Prüfe das Datum in `references/sota.md` (Feld `last_updated`). Ist es älter als 30 Tage, führe zuerst eine Web-Recherche durch (Suchbegriffe stehen in der Datei) und aktualisiere die Datei — dieses Skill hält sich selbst auf dem Stand der Technik.

## Die drei Mix-Punkt-Pfade (Kurzfassung)

1. **Section-basiert**: `dj_brain.calculate_genre_aware_mix_points()` — quantisiert auf Phrasengitter, downbeat-verankert. Der "gute" Pfad.
2. **RMS-Fallback**: `analysis.analyze_structure_and_mix_points()` — baut Pseudo-Sections und delegiert an Pfad 1.
3. **Paar-spezifisch**: `dj_brain.calculate_paired_mix_points()` — überschreibt zur Laufzeit die Werte aus Pfad 1/2 in `playlist.compute_transition_recommendations()` und ist NICHT quantisiert. Das ist die wichtigste bekannte Schwachstelle (B1 in der Map).

## Wie ein echter DJ Mix-Punkte setzt (Referenzverhalten)

- **Mix-Out** liegt auf einer Phrasengrenze am Beginn des letzten energetisch stabilen Abschnitts vor dem Outro — dort, wo die Kick noch läuft, aber melodische Elemente ausdünnen. Nie mitten in einem Breakdown-Aufbau, nie nach dem letzten Drop-Ende.
- **Mix-In** liegt auf einer Phrasengrenze im Intro oder am Intro-Ende von Track B — ein DJ startet Track B typischerweise 16-32 Bars VOR dessen erstem energetischen Abschnitt, sodass der erste Drop von B auf eine Phrasengrenze von A fällt ("phrase matching").
- Beide Punkte sind auf **Phrasen-**, nicht nur Takt-Grenzen quantisiert. Ein um 1 Bar versetzter Mix ist hörbar falsch; um 4 Bars versetzt ruiniert er den Übergang.
- Die Entscheidung hängt an der **Bass-/Kick-Präsenz**, nicht an Breitband-RMS: Ein Pad-Intro gleicher Lautheit ist mixbar, ein laufender Drop nicht überblendbar per Bass-Swap ohne Kollision.

## Fix-Patterns (in Prioritätsreihenfolge)

Details mit exakten Zeilennummern in `references/project-map.md`, Abschnitt "Schwachstellen".

1. **Paar-Mix-Punkte quantisieren (B1)**: Am Ende von `calculate_paired_mix_points()` beide Werte durch `quantize_to_grid(t, grid_seconds, anchor, "floor"/"ceil")` schicken — mit dem jeweiligen `first_downbeat` des Tracks als Anker. Sonst ist alle vorgelagerte Quantisierung Anzeige-Kosmetik.
2. **Positionsterm in der Kandidatenwahl (B4/B5)**: `_find_mix_in_point` braucht `start_time` als Sortierschlüssel (frühe Kandidaten bevorzugen, Suchfenster ~erste 40 %); `_find_mix_out_point` braucht `-end_time` als primäres Kriterium (späte Kandidaten), Label nur als Tiebreak.
3. **Bass-Präsenz vor der Mix-Punkt-Wahl (B6)**: Die Per-Section-Bandanalyse (`avg_bass`) wird derzeit NACH der Mix-Punkt-Berechnung injiziert. Reihenfolge in `analysis.analyze_track()` umstellen, dann `_find_mix_in_point` auf eine `avg_bass`-Schwelle konditionieren (Mix-In bevorzugt dort, wo Bass < ~40; Mix-Out dort, wo Bass > ~50 stabil läuft).
4. **intro_end-Scan-Bug (B7)**: `_get_intro_end_from_sections` darf nur den zusammenhängenden Intro-Block ab Index 0 auswerten — `for s in sections: if s.label != "intro": break`. Sonst kann eine Tail-Fenster-"intro"-Section den Wert ans Track-Ende ziehen.
5. **Overlap-Logik reparieren (B2/B3)**: `target_overlap` für Track B ist im Regelfall toter Code, weil der Intro-Guard immer greift. Entscheide bewusst: Entweder Mix-In wirklich `target_overlap` vor `intro_end` erlauben (DJ-Verhalten, dann Bass von B per EQ raus) oder die Berechnung entfernen. `_dynamic_transition_bars` sollte den Overlap bestimmen, nicht `duration - adjusted_mix_out_a`.
6. **`outro_covered` respektieren (E3)**: Bevor ein Mix-Out aus Sections gewählt wird, prüfen ob `track.outro_covered` — sonst kann der Punkt in einer `"unanalysed"`-Pseudo-Section landen. Fallback: Tail-Analyse anstoßen oder konservativ `duration - phrase*2` verwenden.

## Regeln beim Editieren

- Jede neue Zeitgröße wird IMMER über `models.quantize_to_grid()` mit `anchor=first_downbeat` aufs Gitter gelegt. Kein nacktes `round()`/`min()`/`max()` auf Zeitwerte, die im Renderer landen.
- Richtungskonvention: Mix-In wird ge-`ceil`t (nie vor dem musikalischen Ereignis), Mix-Out ge-`floor`t (nie danach).
- Neue Schwellwerte gehören nach `hpg_core/config.py`, nicht hartkodiert in Funktionen (Projekt-Konvention).
- Nach jeder Änderung: `tests/` laufen lassen (Kommando in CLAUDE.md) UND einen manuellen Plausibilitätscheck: Mix-In < 50 % der Tracklänge, Mix-Out > Mix-In + 2 Phrasen, beide auf `anchor + k*phrase_seconds` (Toleranz 1e-3 s).
- 2 Leerzeichen Einrückung, Kommentare auf Deutsch, keine Änderungen an LOCKED-Konstanten.

## Verifikation (Pflicht nach jedem Fix)

Schreibe einen kleinen Check (oder nutze `tools/`), der für eine Handvoll analysierter Tracks prüft:

```
phase_in  = (mix_in_point  - first_downbeat) % (seconds_per_bar * phrase_unit)
phase_out = (mix_out_point - first_downbeat) % (seconds_per_bar * phrase_unit)
# beide müssen ~0 oder ~grid sein (Floating-Point-Toleranz)
```

Und für Paare: `recommendation.next_mix_in` / `current_mix_out` müssen dieselbe Bedingung erfüllen — das ist der Wert, der wirklich gerendert wird.
