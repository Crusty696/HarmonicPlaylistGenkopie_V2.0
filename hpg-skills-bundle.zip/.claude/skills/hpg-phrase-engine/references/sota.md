# State of the Art: Phrasen-/Struktur-Analyse

last_updated: 2026-07-24
update_interval_days: 30

## Auto-Update-Anweisung

Wenn `last_updated` älter als `update_interval_days`: Web-Suchen mit "music structure analysis segmentation <Jahr>", "downbeat tracking state of the art", "MIREX music structure analysis", "phrase boundary detection electronic dance music". Datei aktualisieren, `last_updated` setzen, dem User kurz berichten was neu ist.

## Referenzen (Stand Juli 2026)

- **allin1 — All-In-One Music Structure Analyzer** (Kim & Nam, arXiv:2307.16425): Beats, Downbeats, Tempo UND funktionale Segmente (intro/verse/chorus/drop/break/outro) in einem Modell mit Neighborhood Attention auf demixtem Audio (Demucs). Bester Kandidat für ein komplettes Analyse-Backend-Upgrade. https://github.com/mir-aidj/all-in-one · PyPI `allin1`, Community-Fix `all-in-one-fix` (Dependency-Probleme mit neueren numpy/torch — vor Einbau Kompatibilität mit numpy<2-Constraint des Projekts prüfen!)
- **Beat This!** (Foscarin et al., CPJKU, ISMIR 2024): Beat/Downbeat ohne DBN-Postprocessing, genre-robust, klar besser als madmom/BeatNet auf Out-of-Domain-Material. https://github.com/CPJKU/beat_this — Kandidat als Ersatz für `downbeat.estimate_first_downbeat` (liefert verlässliche Downbeats → Phrasen-Voting darauf aufsetzen).
- **Beat Transformer** (Zhao et al., ISMIR 2022): Demixed Beat/Downbeat mit Dilated Self-Attention — Vorgänger-SOTA.
- **BEAST** (arXiv:2312.17156): Streaming-Transformer für Online-Beat-Tracking (nur relevant, falls HPG Live-Features bekommt).
- **MIREX Music Structure Analysis** (music-ir.org/mirex/wiki/2025:Music_Structure_Analysis): jährlicher Benchmark — dort nach neuen Segmentierungs-Siegern schauen.
- Klassik-Baseline: Foote-Novelty/Checkerboard (im Projekt implementiert), MSAF-Bibliothek als Referenzsammlung.

## Wichtig fürs Projekt

- Projekt-Constraint: numpy<2, scipy<1.16, librosa 0.10.x (siehe audio-ml-pipeline Skill / pyproject). allin1/beat_this ziehen torch — Installation isoliert testen, GPU optional.
- Phrasen-Phase gibt es in KEINEM Off-the-shelf-Tool direkt — die Bar-Voting-Methode (SKILL.md Rezept 1) bleibt nötig; gute Downbeats aus Beat This!/allin1 machen sie nur zuverlässiger.
