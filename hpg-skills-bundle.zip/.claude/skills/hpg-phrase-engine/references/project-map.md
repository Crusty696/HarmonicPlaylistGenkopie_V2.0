# Code-Landkarte: Phrasing & Struktur in HPG V2.0

Stand: 2026-07-24. Zeilennummern können driften — im Zweifel greppen.

## structure_analyzer.py

### Pipeline `analyze_structure()` — Z. 534-635
1. `_compute_novelty_curve` (90-174): MFCC n_mfcc=13, hop=1024 → `librosa.segment.recurrence_matrix(mode='affinity', sym=True)`, width≈4s; Checkerboard-Novelty manuell (self_sim - cross_sim, Kernel≈2s), Hanning-8-Glättung; `MAX_SSM_FRAMES=3000` (Dezimierung per step)
2. `_pick_boundaries` (177-251): lokale Maxima ≥ threshold (Start `SECTION_ENERGY_THRESHOLD=0.3`, iterativ -0.05 bis 0.1); Mindestabstand `max(MIN_SECTION_DURATION=8.0, seconds_per_bar*phrase_unit*0.5)`; `MAX_SECTIONS=12`, `MIN_SECTIONS=3`
3. `_quantize_to_bars` (254-307): Gitter = HALBE Phrase, `grid_bars = min(8, max(2, phrase_unit//2))` → 4 Bars (phrase 8) / 8 Bars (phrase 16); downbeat-verankert; Mindestabstand 2 Bars
4. `_compute_section_energy` (310-348): Breitband-RMS, track-relativ (`scale = max(0.4, track_rms*1.6)`), 0-100
5. `_compute_energy_trend` (351-379): 1. vs. 2. Hälfte, ratio>1.3 rising, <0.7 falling
6. `_label_sections` (382-484): Labels intro/build/drop/breakdown/outro/main
   - `ENERGY_HIGH_THRESHOLD=1.2`, `ENERGY_LOW_THRESHOLD=0.6`, `ENERGY_BUILD_THRESHOLD=0.9` (UNBENUTZT), `ENERGY_BREAKDOWN_THRESHOLD=0.8`
   - intro nur Index 0 (+1 falls boundaries[1] < 0.25*dur); outro nur -1 (+-2 falls > 0.75*dur)
   - `build` NUR direkt vor `drop` UND trend=="rising" (471-475)
7. Fallback `_calculate_rms_and_phrase_boundaries` (486-529): 3 Grenzen aus RMS > 40 % Mittel; Plausibilisierung 0.35/0.65; sonst `phrase_unit*2` Bars Intro/Outro

### phrase_unit
`GENRE_PHRASE_UNITS` (64-67), abgeleitet aus `genres.GENRE_MIX_PROFILES[*].phrase_unit`:
16 = Psytrance, Trance · 8 = Tech House, Progressive, Melodic Techno, Techno, Deep House, DnB, Minimal, Unknown/Default.
KEINE Messung. `config.BARS_PER_PHRASE=8` ist toter Code.

### Datenklassen
`TrackSection` (36-50): label, start_time, end_time, start_bar, end_bar, avg_energy, duration(), to_dict().
Nachträglich in Dicts injiziert (analysis.py:1187-1204, 1419-1421): avg_bass, avg_mids, avg_highs, percussive_ratio, spectral_flatness, analysis_status.
`TrackStructure` (53-58): sections, total_bars, phrase_unit.

## downbeat.py

### `estimate_first_downbeat(y, sr, bpm) -> (seconds, confidence)` — Z. 53-189
Nach Vande Veire & De Bie (EURASIP 2018):
1. `librosa.beat.beat_track(start_bpm=bpm, trim=False, hop_length=1024)`
2. Trim leiser Beats: `loud >= loud_max * _TRIM_RATIO(0.3)`, `_MIN_BEATS=16`
3. Indizien pro Beat (z-normiert): Bass-Onset (`onset_strength(fmax=160, n_mels=16)`), Chroma-Novelty (Cosinus ±Grenze), Loudness-Akzent (loud - movmean(5))
4. `_WEIGHTS=(1.0, 1.0, 0.5)`; Voting über `beat_index % 4` — NUR Takt-Phase, keine Phrasen-Phase!
5. `confidence = clip((votes[0]-votes[1])/sum(|votes|), 0, 1)` — typisch weit unter 0.9
6. Fein-Snap auf stärksten Bass-Onset im ±½-Beat-Fenster
Vorrang: Rekordbox-ANLZ (`rekordbox_importer.get_first_downbeat`) → confidence 1.0 (analysis.py:977-986).

## Quantisierung

`models.quantize_to_grid(t, grid, anchor, mode)` — models.py:25-45. Einzige Grid-Funktion, Modi ceil/floor/round, anker-relativ. Anker ist überall `first_downbeat` — das Phrasengitter `anchor + k*phrase_seconds` hat daher WILLKÜRLICHE Phrasen-Phase (Schwachstelle A1).

## Fenster-Analyse (lange Tracks)

`analysis.analyze_structure_windows` (841-907): Kopf ≤600s (360s Rekordbox-Fastpath) + Tail `LIBROSA_TAIL_DURATION=180s`; Mitte = Pseudo-Section label="unanalysed", avg_energy=0.0; `outro_covered` Flag.
Achtung: Tail-Fenster kann eigene "intro"-Sections labeln → intro_end-Bug in dj_brain (siehe hpg-mix-points Skill, B7).

## Schwachstellen

- **A1** Keine Phrasen-Phase — Gitter kann bis phrase_unit-1 Bars neben echten Phrasengrenzen liegen
- **A2** phrase_unit = Genre-Konstante; Unknown → immer 8, auch bei 16-Bar-Trance
- **A3** Section-Gitter (halbe Phrase) ≠ Mix-Punkt-Gitter (ganze Phrase)
- **E1** build nur vor erkanntem drop; ENERGY_BUILD_THRESHOLD unbenutzt
- **E2** Section-Energie = Breitband-RMS (Breakdown mit lauten Pads = Drop-Energie)
- **E4** Nur MFCC-SSM, keine Chroma-/Bass-Kanäle
