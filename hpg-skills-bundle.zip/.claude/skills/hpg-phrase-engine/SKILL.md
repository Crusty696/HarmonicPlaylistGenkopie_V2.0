---
name: hpg-phrase-engine
description: Experten-Skill für Phrasen-Erkennung und Track-Struktur im HPG Harmonic Playlist Generator V2.0 (8/16/32-Bar-Phrasen, Downbeats, Sections). IMMER verwenden bei Arbeit an structure_analyzer.py, downbeat.py, phrase_unit, quantize_to_grid, first_downbeat, Section-Labels (intro/build/drop/breakdown/outro), Novelty-Kurven, Boundary-Detection, oder wenn der User sagt "die Phrasen stimmen nicht", "Übergang sitzt nicht auf der Phrase", "Struktur wird falsch erkannt", "Drop wird nicht erkannt". Enthält die exakte Code-Landkarte und die Algorithmen für Phrasen-Phase-Schätzung.
---

# HPG Phrase Engine Expert

Phrasing ist das Fundament von allem: Ein DJ denkt nicht in Sekunden, sondern in Phrasen (8/16/32 Bars). Jeder Mix-Punkt, jeder Übergang und jedes Alignment in HPG hängt an drei Größen: `first_downbeat` (Takt-Phase), `phrase_unit` (Phrasenlänge) und der **Phrasen-Phase** (wo die erste Phrase beginnt). Die dritte existiert im Projekt noch nicht — das ist die wichtigste Lücke.

## Bevor du irgendetwas änderst

1. Lies `references/project-map.md` — exakte Landkarte von `structure_analyzer.py`, `downbeat.py` und den Quantisierungsstellen.
2. Prüfe `references/sota.md` (`last_updated`): älter als 30 Tage → Web-Recherche laut Anweisungen in der Datei, dann Datei aktualisieren.

## Ist-Zustand in einem Satz

Sections werden über eine MFCC-Self-Similarity-Novelty-Kurve gefunden, auf ein Halb-Phrasen-Gitter gesnappt und per Energie-Heuristik gelabelt; `phrase_unit` ist eine Genre-Konstante (8 oder 16), und der Quantisierungs-Anker ist nur die Takt-"1", nicht der Phrasenanfang — das Phrasengitter kann also um bis zu `phrase_unit - 1` Bars neben den echten Phrasengrenzen liegen.

## Kern-Konzepte, DJ-korrekt

- **Takt-Phase**: welcher Beat ist die "1"? (`downbeat.estimate_first_downbeat`, Voting über `beat_index % 4`) — vorhanden.
- **Phrasen-Phase**: welcher Takt ist Takt 1 einer Phrase? — FEHLT. In EDM beginnen Phrasen dort, wo neue Elemente einsetzen/aussetzen: Kick-Einsatz, Snare-Roll-Ende, Filter-Öffnung, harmonischer Wechsel.
- **Phrasenlänge**: 8 Bars (House/Techno-Familie), 16 Bars (Trance/Psytrance), gelegentlich 32. Sollte gemessen werden (Periodizität), Genre nur als Prior.

## Implementierungs-Rezepte

### 1. Phrasen-Phase schätzen (höchste Priorität, A1)

Erweitere die Voting-Idee von `estimate_first_downbeat` auf Bar-Ebene:

```
1. Beats + first_downbeat wie bisher bestimmen → Bar-Grenzen ableiten
2. Pro Bar-Grenze Indizien berechnen (z-normiert):
   - Bass-Onset-Stärke (onset_strength, fmax≈160)
   - Chroma-Novelty (Cosinus-Distanz der Chroma-Mittel ±1 Bar)
   - RMS-Delta (Energie-Sprung zur Vorgänger-Bar)
   - Novelty-Kurven-Wert des Structure Analyzers an dieser Grenze
3. Voting über bar_index % phrase_unit → Phase mit höchster Summe
4. confidence analog downbeat.py: (votes[0]-votes[1]) / sum(|votes|)
5. Ergebnis als NEUES Track-Feld `first_phrase` (Sekunden) + `phrase_confidence`
```

Danach überall dort, wo `anchor=first_downbeat` fürs PHRASEN-Gitter benutzt wird, `first_phrase` verwenden (Takt-Gitter bleibt bei `first_downbeat`). Cache-Schema beachten: neues Feld ⇒ Cache-Version bump (`caching.py`, hpg_cache_v14.db).

### 2. `phrase_unit` messen statt raten (A2)

Autokorrelation der Bar-aggregierten Novelty-/Onset-Kurve; Peaks bei Lag 8 vs. 16 vergleichen; Genre-Profil als Prior gewichten (z. B. Bayes-artig: gemessene Evidenz × Genre-Prior). Bei `detected_genre == "Unknown"` fällt der aktuelle Code stumpf auf 8 zurück — genau dort hilft die Messung am meisten.

### 3. Section-Gitter = Mix-Gitter (A3)

`_quantize_to_bars` snappt Grenzen auf HALBE Phrasen (`grid_bars = min(8, max(2, phrase_unit // 2))`), die Mix-Punkte aber auf GANZE. Wer hier arbeitet: entweder beide auf ganze Phrasen oder den Mix-Punkt-Code explizit halb-Phrasen-tolerant machen — nicht stillschweigend mischen.

### 4. Novelty-Kurve verbessern (E4)

Aktuell nur Breitband-MFCC-SSM. Ergänze zwei Kanäle und mittle die Novelty-Kurven: Chroma-SSM (harmonische Wechsel = typische Phrasengrenze) und ein Bass-/Percussion-Kanal (Kick-Pattern-Wechsel). Speicher-Guard `MAX_SSM_FRAMES = 3000` beibehalten.

### 5. Label-Heuristik (E1)

`build` entsteht nur direkt vor einem erkannten `drop` — Tracks ohne Drop haben nie ein `build`, und `build` ist Top-Priorität der Mix-In-Wahl. `ENERGY_BUILD_THRESHOLD = 0.9` ist definiert, aber nie benutzt. Wenn du Labels anfasst: `build` zusätzlich über `trend == "rising"` UND Energie im Band [0.6, 1.2] zulassen, unabhängig vom Nachfolger.

## Regeln

- Downbeat-Anker: Rekordbox-ANLZ-Beatgrid (confidence 1.0) hat IMMER Vorrang vor der Eigen-Schätzung.
- Neue Felder in `Track` dokumentieren (models.py, `ANALYSIS_FIELD_CONSUMERS`-Tabelle pflegen) und Cache-Version bumpen.
- Grenzwerte nach `config.py`, Kommentare Deutsch, 2 Leerzeichen.
- Verifikation: für Test-Tracks mit bekannter Struktur (tools/ hat Manual-Test-Helfer) prüfen, dass `first_phrase` auf einem hörbaren Element-Einsatz liegt und `(section_boundary - first_phrase) % phrase_seconds ≈ 0`.

## Upgrade-Pfad (optional, siehe sota.md)

`allin1` liefert Beats, Downbeats und funktionale Segment-Labels in einem Modell auf demixtem Audio — als alternatives Analyse-Backend hinter einem Feature-Flag denkbar. `Beat This!` (CPJKU) ersetzt die Downbeat-Heuristik mit deutlich höherer Confidence. Beides erst NACH den strukturellen Fixes oben einbauen, sonst optimierst du auf einem schiefen Fundament.
