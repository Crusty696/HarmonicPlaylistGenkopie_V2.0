---
name: hpg-sota-updater
description: Auto-Update-Skill, der alle HPG-Experten-Skills (hpg-mix-points, hpg-phrase-engine, hpg-harmonic-mixing, hpg-transition-quality) auf den neuesten Stand der Technik bringt. IMMER verwenden wenn der User sagt "skills updaten", "auf den neusten Stand bringen", "was gibt es Neues in MIR/Audio-Analyse", "sota update", "/hpg-update", oder automatisch zu Beginn größerer Arbeitssessions am HPG-Projekt, wenn die sota.md-Dateien der Skills älter als 30 Tage sind. Recherchiert aktuelle Forschung (Beat-Tracking, Structure Analysis, Key Detection, DJ-Transition-Generierung) und schreibt die references/sota.md-Dateien der Skills fort.
---

# HPG SOTA Updater

Dieses Skill hält die vier HPG-Experten-Skills aktuell. Jeder von ihnen trägt eine `references/sota.md` mit `last_updated`-Datum. Deine Aufgabe: prüfen, recherchieren, fortschreiben.

## Ablauf

1. **Skills lokalisieren**: Projekt-Skills liegen in `.claude/skills/` im Repo-Root des HPG-Projekts (`hpg-mix-points`, `hpg-phrase-engine`, `hpg-harmonic-mixing`, `hpg-transition-quality`). Falls dort nicht vorhanden, den User nach dem Installationsort fragen.
2. **Frische prüfen**: In jeder `references/sota.md` das Feld `last_updated` lesen. Jünger als `update_interval_days` (Default 30)? → überspringen, kurz melden.
3. **Recherchieren** (Web-Suche, pro veraltetem Skill die in seiner sota.md hinterlegten Suchbegriffe verwenden, Jahr aktualisieren). Zusätzlich quer für alle: "ISMIR <Jahr> proceedings beat tracking structure analysis", "MIREX <Jahr> results". Auf Hugging Face nach neuen Audio-/MIR-Modellen suchen, wenn entsprechende Tools verfügbar sind (hub_repo_search: "beat tracking", "music structure", "key detection").
4. **Bewerten**: Neu gefundene Paper/Modelle gegen die vorhandenen Einträge stellen. Relevanz-Kriterien: läuft lokal (Windows, Python 3.12), verträgt sich mit den Projekt-Constraints (numpy<2, scipy<1.16, librosa 0.10.x, PyQt6), realer Genauigkeitsgewinn für EDM-Material, Aufwand.
5. **Fortschreiben**: Jede betroffene `sota.md` aktualisieren — Neues ergänzen (mit URL + 1-Satz-Einschätzung "Übertrag auf HPG"), Überholtes als überholt markieren (nicht löschen — Historie hilft), `last_updated` auf heute setzen.
6. **Code-Drift prüfen** (wichtig!): Stichprobenartig 2-3 Zeilennummern-Angaben aus den `references/project-map.md`-Dateien gegen den echten Code greppen. Bei Drift: Zeilennummern korrigieren und das Analysedatum in der project-map anpassen. Die Landkarten sind das Herz der Skills — veraltete Landkarten sind schlimmer als keine.
7. **Berichten**: Dem User eine kompakte Zusammenfassung geben: was ist neu, was wurde als überholt markiert, welche konkrete Chance ergibt sich für HPG (max. 5 Punkte).

## Regeln

- Niemals SKILL.md-Beschreibungen oder Fix-Patterns automatisch umschreiben — nur die `references/`-Dateien. Änderungen an den Patterns selbst schlägst du dem User vor.
- Quellen immer mit URL. Keine Einträge ohne Primärquelle (Paper, GitHub-Repo, offizielle Doku).
- Wenn ein neues Tool einen bestehenden Upgrade-Pfad obsolet macht (z. B. ein Nachfolger von allin1), explizit im Bericht hervorheben.
- Bei fehlendem Web-Zugriff: abbrechen und dem User sagen, dass das Update Web-Suche braucht — nicht aus dem Gedächtnis "aktualisieren".
