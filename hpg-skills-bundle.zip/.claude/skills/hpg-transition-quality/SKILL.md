---
name: hpg-transition-quality
description: Experten-Skill für Transition-Scoring, DJ-Brain-Empfehlungen, Set-Dramaturgie (Energy Arc) und Audio-Rendering von Übergängen im HPG Harmonic Playlist Generator V2.0. IMMER verwenden bei Arbeit an playlist.py-Scoring/Strategien, dj_brain.py-Empfehlungen, transition_renderer.py (Crossfades, EQ, Beat-Alignment, Time-Stretch), Vocal-Clash, energy_flow, calculate_enhanced_compatibility, Playlist-Strategien (Peak-Time, Harmonic Flow, Context Flow), oder wenn der User sagt "Übergänge klingen schlecht", "Preview klingt versetzt", "Playlist hat keinen Spannungsbogen", "wie ein echter DJ mischen". Enthält Scoring-Gewichte, Render-Pipeline und alle bekannten Schwachstellen.
---

# HPG Transition Quality Expert

Ziel: Übergänge, die klingen wie von einem echten DJ — beatgenau, phrasengenau, mit sauberem EQ-Handover, ohne Vocal-Kollision, eingebettet in einen Set-Spannungsbogen.

## Bevor du irgendetwas änderst

1. Lies `references/project-map.md` — Scoring-Gewichte, Strategien, Render-Pipeline mit Zeilennummern.
2. Prüfe `references/sota.md` (`last_updated` > 30 Tage → Web-Recherche laut Datei, dann aktualisieren).

## Was einen Übergang wirklich gut macht (Referenzwissen)

In dieser Reihenfolge, nach hörbarer Wichtigkeit:

1. **Phrasen-Alignment** — Drop/Break von B fällt auf Phrasengrenze von A. Ein perfekt EQ-ter, aber um 2 Bars versetzter Mix klingt immer falsch.
2. **Bass-Disziplin** — nie zwei Bässe gleichzeitig. Bass-Swap auf der Phrasengrenze, mit 1-Beat-Rampe.
3. **Vocal-Disziplin** — nie zwei Lead-Vocals übereinander; Vocal von A muss vor dem Vocal-Einsatz von B raus.
4. **Tempo-Fahrt** — Anpassung graduell (Ramp), nicht als konstanter Stretch; realistisch ±6-8 %, mit Key-Lock ab ~±3 %.
5. **Energie-Logik** — Übergang passt zur Set-Phase (Warmup/Build/Peak/Cooldown); ein Energie-Cliff (>30 Punkte) ist fast immer ein Fehler.
6. **Lautheit** — LUFS-Sprünge > 1.5 dB hörbar, > 3 dB inakzeptabel.

## Die wichtigsten Baustellen im Projekt

Details/Zeilen in `references/project-map.md`. Priorisiert:

1. **Alignment nur auf Beat-, nicht Takt-/Phrasen-Ebene (C1)**: `_align_beat_phase` rechnet `offset % beat_len` — Kick sitzt auf Kick, aber Backbeat und Phrase können versetzt sein. Fix: `% (beat_len * METER)` für die Takt-Phase; Phrasen-Offset aus `first_phrase` (siehe hpg-phrase-engine), sobald das Feld existiert.
2. **Exakter Alignment-Pfad ist praktisch tot (C2)**: verlangt `downbeat_confidence >= 0.9` für BEIDE Tracks — die Eigen-Heuristik liefert das fast nie, also läuft fast immer die 8-s-Schätzung (30-380 ms Fehler). Fix: Schwelle senken (~0.6) ODER Downbeat-Backend verbessern, UND die Schwelle in `config.py` ziehen.
3. **Linearer Crossfade (C3)**: erzeugt -3-dB-Loch in der Mitte. Fix: Equal-Power (`cos/sin`-Kurven); das Feld `TransitionPlan.curve` existiert schon, wird aber nie ausgewertet — auswerten statt neues Feld erfinden.
4. **Vocal-Clash wird nicht bewertet (D2)**: `vocal_instrumental` existiert pro Track, hat aber laut `ANALYSIS_FIELD_CONSUMERS` keinen Consumer. Fix in zwei Stufen: (a) billig: Penalty in `calculate_enhanced_compatibility`, wenn beide Tracks "vocal" UND der Overlap in Sections mit hohen `avg_mids` liegt; (b) richtig: Vocal-Präsenz PRO SECTION erkennen (siehe sota.md) und nur echte Überlappung bestrafen.
5. **Kein globaler Energy Arc (D1)**: Nur `Context Flow` kennt Zielenergie-Phasen; alle anderen Strategien optimieren paarweise-greedy. Fix-Idee: Arc-Kostenterm als optionalen Faktor in ALLE Strategien geben (Zielkurve aus Strategie ableiten: Peak-Time = asymmetrische Kurve, Warm-Up = monoton steigend …) statt jede Strategie einzeln umzubauen.
6. **Stretch ohne Key-Lock, bis ±15 % (C4)** und **ohne Ramp (C5)**: ±15 % sind ~2.4 Halbtöne — hörbar verstimmt gegenüber dem Camelot-Score. Clamp auf ±8 % senken, ab ±3 % Key-Verschiebung ins Harmonic-Scoring rückmelden (siehe hpg-harmonic-mixing, Pattern 3), langfristig `pyrubberband`/Key-Lock evaluieren.
7. **Texture-Score ist Anzeige-only (D3)** und **Genre-Default 0.5 wirkt mit 20 % (D4)**: `_calculate_texture_similarity` (Timbre-Cosine) in den Score aufnehmen — gerade bei unbekanntem Genre der bessere Ähnlichkeitsmesser; bei genau einem "Unknown"-Genre das Genre-Gewicht auf Texture umverteilen.

## Regeln

- Scoring-Gewichte sind vielfach abgetestet (1200+ Tests) — vor jeder Gewichtsänderung die betroffenen Tests lesen; Gewichte/Schwellen nach `config.py`.
- `predict_transition_type` (8 Regeln) und die EQ-Modi des Renderers sind gekoppelt — neue Transition-Typen brauchen beide Seiten plus Test.
- Renderer: Soft-Limiter und RMS-Normalisierung (-14 dBRMS) nicht entfernen; PCM_16-Export beibehalten; UI-Updates nur im Main-Thread (Worker-Pattern, siehe pyqt6-threading Skill).
- Kommentare Deutsch, 2 Leerzeichen, LOCKED-Konstanten unberührt.

## Verifikation (Pflicht)

- **Hör-Check ersetzt nichts**: Nach Renderer-Änderungen 2-3 Preview-Clips rendern (tools/ Manual-Test) und anhören bzw. Waveform prüfen: keine Doppel-Kick im Overlap (Autokorrelation des Bass-Bands im Übergangsfenster zeigt EINE Periodizität), kein Pegel-Loch in der Fade-Mitte (RMS-Verlauf glatt), Übergang startet auf `anchor + k*phrase_seconds`.
- Scoring-Änderungen: Verteilung der overall_scores über eine echte Library vergleichen (vorher/nachher), nicht nur Unit-Tests — Gewichtsänderungen verschieben Ranglisten subtil.
