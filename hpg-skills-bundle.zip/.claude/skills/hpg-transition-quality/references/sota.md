# State of the Art: DJ-Transitions & Set-Dramaturgie

last_updated: 2026-07-24
update_interval_days: 30

## Auto-Update-Anweisung

Wenn `last_updated` älter als `update_interval_days`: Web-Suchen mit "automatic DJ transition generation <Jahr>", "DJ mix generation deep learning", "vocal activity detection music", "equal power crossfade key lock time stretch". Datei aktualisieren, `last_updated` setzen, dem User kurz berichten.

## Referenzen (Stand Juli 2026)

- **DJtransGAN** (Chen et al., arXiv:2110.06525): Übergangs-Generierung mit differenzierbaren Audio-Effekten + GAN — lernt Fader/EQ-Kurven aus echten DJ-Mixen. Konzeptquelle für parametrisierte EQ-Kurven statt fester Presets.
- **DJ AI (Audio Mostly 2025)**: Playlist-Alignment + Transition-Generierung mit generativen und Embedding-Modellen. https://dl.acm.org/doi/full/10.1145/3771594.3771640
- **Automatic DJ Mix Generation Using Highlight Detection** (Kim et al.): Highlight-/Drop-zentrierte Mixplanung — Argument dafür, Mix-Fenster relativ zu Drops statt zu Intro/Outro zu planen.
- **Vande Veire & De Bie (EURASIP 2018)**: komplette Auto-DJ-Pipeline für DnB inkl. Crossfade-/EQ-Regeln; Basis mehrerer HPG-Heuristiken.
- **Vocal Activity Detection**: Praktikabel via Stem-Separation (Demucs/HTDemucs, im Schwester-Projekt vorhanden — siehe audio-ml-pipeline Skill) → Vocal-Stem-RMS pro Section; leichtgewichtige Alternative: Silero-VAD/spleeter-basierte Heuristiken. Für HPG: Vocal-Präsenz PRO SECTION cachen, nicht pro Track.
- **Key-Lock/Time-Stretch**: `pyrubberband` (Rubber Band Library) für formant-/tonhöhenerhaltendes Stretching; librosa.effects.time_stretch ist Phase-Vocoder OHNE Key-Lock.
- **Equal-Power-Crossfade**: Standard cos/sin-Kurven; bei korrelierten Signalen (beatsynced!) ist ein linearer Fade korrekt, bei unkorrelierten equal-power — DJ-Übergänge liegen dazwischen; praktikabel: equal-power als Default, linear nur für bass_swap-Mitte.

## Übertrag auf HPG

Reihenfolge: (1) Phrasen-Alignment (hängt an hpg-phrase-engine), (2) Equal-Power + curve-Feld auswerten, (3) Vocal-Präsenz pro Section + Scoring-Penalty, (4) Stretch-Clamp ±8 % + Key-Shift-Rückmeldung ans Harmonic-Scoring, (5) Tempo-Ramp, (6) langfristig gelernte EQ-Kurven (DJtransGAN-Richtung). GPU-/Dependency-Constraints des Projekts beachten (numpy<2; Demucs nur falls ohnehin installiert).
