# Code-Landkarte: Transition-Scoring, Strategien & Rendering in HPG V2.0

Stand: 2026-07-24. Zeilennummern können driften — im Zweifel greppen.

## Scoring

### `playlist.calculate_enhanced_compatibility` — playlist.py:210-290
```
genre_weight = 0.2 (mit DJ-Brain-Genres) | 0.1 (ohne)   # has_dj_brain_genres: playlist.py:255-263
remaining    = 1.0 - genre_weight
overall = (remaining*0.44)*harmonic/100
        + (remaining*0.28)*bpm_smoothness      # exp(-bpm_diff / max(tol/2, 1e-9))
        + (remaining*0.28)*energy_flow         # richtungsabhängig via EnergyDirection, sonst 1-|Δ|/100
        + genre_weight*genre_compatibility
overall = min(1.0, overall + ai_bonus)         # ai_bonus ≤ 0.14 (Mood 0.08 + Subgenre 0.06/0.03), playlist.py:157-199
if bpm_diff > bpm_tolerance: overall = 0.0     # Hard Gate
```
Effektiv (mit Genres): Harmonic 0.352 / BPM 0.224 / Energy 0.224 / Genre 0.20.
`calculate_playlist_quality` (1338-1405): 0.5*harmonic + 0.25*energy + 0.25*bpm.

### Bekannte Scoring-Lücken
- **D2** `vocal_instrumental` ohne Consumer (models.py:87, ANALYSIS_FIELD_CONSUMERS); Heuristik `detect_vocal_instrumental` (analysis.py:345-415, Schwellen flatness<0.03, mfcc_var>80, contrast>30) auf 22kHz-Mono unsicher
- **D3** `_calculate_texture_similarity` (dj_brain.py:1192-1216, Timbre-Cosine ohne MFCC-0) nur Anzeige
- **D4** Genre-Default 0.5 bei Unknown (dj_brain.py:60-63) wirkt mit vollem Gewicht, wenn nur EIN Genre unbekannt
- **D5** `_apply_harmonic_smoothing` (playlist.py:730-753) bewertet Swap ohne Anschluss-Transition [i+1]→[i+3]
- **D6** Magic Numbers: energy_disruption<20 (752), Cliff>35 (1517), Boni +10/+5/±4/-12/-15 (1500-1518)

## Strategien — `playlist.STRATEGIES` (1544-1553)

Harmonic Flow (Lookahead depth 2, `LOOKAHEAD_TOP_K=8`) · Warm-Up (BPM asc) · Cool-Down (desc) · Peak-Time (peak_position 0.7, Exponent 1.5/0.7, + `_apply_harmonic_smoothing` max 3 Iter.) · Energy Wave (`_sort_energy_wave` 623-655 — ignoriert Harmonik+BPM!) · Genre Flow · Consistent · Context Flow.

### `_sort_context_flow` (1408-1532) — einzige Strategie mit Set-Dramaturgie
- Phasen-Zielenergie {warmup:30, build:60, peak:85, cooldown:40}, Grenzen 0.2/0.5/0.8
- energy_direction-Presets: Build Up 30→85, Cool Down 85→30, Maintain=Poolmittel
- Boni max +19 (bewusst < 20-Punkte-Camelot-Stufe): Phasen-Nähe +10, Trend +5, Genre-Fatigue ±4/-6 ab Streak 4, Repetition -12, Energie-Cliff (>35) -15
- **D1**: Peak nur nachträglich via `compute_set_timeline`/`_identify_peak_track` (1786-1808)

## DJ Brain

- `generate_dj_recommendation` (um Z. 418): setzt `overlap_seconds = duration_a - adjusted_mix_out_a` — überschreibt `_dynamic_transition_bars`
- `_dynamic_transition_bars(ctx)` (932-970): Basis=Mittel der transition_bars-Endpunkte; +8 bei BPM-Diff>8, +4 bei >4, +4 bei Energie-Diff>25; min(base,16) bei half/double; -4 bei Perfect Match; 4er-Raster, min 8
- `_get_cross_genre_technique` (973-1039) / `_get_cross_genre_eq` (1040-1099): frozenset-Paar-Tabellen; Fallback wenn `get_genre_compatibility < 0.3`
- `_assess_transition_risks` (1102-1188): Half/Double, BPM>4/8, Energie>15/30, Genre<0.4/0.6, Camelot-Distanz>2, Bass-Kollision (bass_a>60 and bass_b>60; bass_b>80), key_confidence<0.5, LUFS≥3dB
- Text-Advice: `_bpm_advice` 769-813, `_key_advice` 816-864, `_gain_advice` 867-884, `_energy_advice` 887-929, `_build_structure_note` 742-766

## Renderer — `transition_renderer.render_transition_clip(spec, path)` (105-254)

1. `_load_segment` (soundfile, librosa-MP3-Fallback), pre/post_roll 30 s
2. Time-Stretch B auf Tempo A: `rate = target_bpm_b / bpm_a`, **Clamp 0.85-1.15** (Z. 159); Half/Double-Toleranz `bpm_a*0.04`; KEIN Key-Lock, KEIN Ramp
3. `_rms_normalize` beide auf -14.0 dBRMS
4. `_align_beat_phase` (285-328): `offset % beat_len` (Z. 312) — nur Beat-Phase! Exakt-Pfad nur bei `downbeat_confidence >= 0.9` BEIDER Tracks (92-97, 204), sonst `_estimate_first_beat` (8-s-Fenster, 30-380 ms Fehler)
5. `_apply_eq_crossfade` (499-674) je transition_type:
   - bass_swap: LP/HP 200 Hz, Bass-Handover @½ mit 50-ms-Rampe
   - pro_eq_swap: 3-Band fc 120/2500 Hz; Lows Swap @½, Mids -6dB-Komplementär, Highs asymmetrisch (A bis ¾, B ab ¼)
   - filter_ride: HP 800 Hz auf A · smooth_blend: LP 300 Hz auf A · breakdown_bridge: HP 250 Hz auf A
   - cold_cut @½ · drop_cut (A fade bis ½) · echo_out (3 Reflexionen, 0.5 s, FB 0.45^i)
   - Fallback: **linearer** Crossfade (fo/fi = linspace, Z. 511-512); `TransitionPlan.curve="linear"` (playlist.py:125) wird NIE ausgewertet
6. Soft-Limiter bei Peak>0.95, Export PCM_16

Typ-Auswahl: `playlist.predict_transition_type` (943-1035), 8 Regeln über eff_diff/energy_delta/harmonic_score/Genre-Sets (melodic_genres, hard_genres, pro_eq_genres).
`TransitionPlan` (playlist.py:115-132, frozen): mix_out_a, mix_in_b, fade_out_start/end, overlap, transition_type, curve, eq_mode, tempo_ratio, target_sr=44100.

## Schwachstellen-Kurzliste

C1 Beat- statt Takt/Phrasen-Alignment · C2 Exakt-Pfad tot (0.9-Schwelle) · C3 linearer Fade, curve ignoriert · C4 ±15 % Stretch ohne Key-Lock · C5 kein Tempo-Ramp · D1 kein globaler Energy Arc · D2 Vocal ungenutzt · D3 Texture ungenutzt · D4 Genre-0.5-Default · D5 Smoothing unvollständig · D6 Magic Numbers
