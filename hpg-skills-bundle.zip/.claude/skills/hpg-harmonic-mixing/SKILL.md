---
name: hpg-harmonic-mixing
description: Experten-Skill für Key-Detection und harmonisches Mixing (Camelot Wheel) im HPG Harmonic Playlist Generator V2.0. IMMER verwenden bei Arbeit an Key-Erkennung, camelotCode, key_confidence, Krumhansl-Profilen, _calculate_compatibility_inner, harmonic_score, Tonart-Kompatibilität, Energy-Boost-Mixing (+1/+2/+7-Techniken), oder wenn der User sagt "Keys passen nicht", "Key-Erkennung falsch", "Playlist klingt nicht harmonisch", "harmonic mixing verbessern". Enthält die exakte Scoring-Tabelle, Code-Landkarte und DJ-korrekte Camelot-Regeln.
---

# HPG Harmonic Mixing Expert

Ziel: Playlists, deren Übergänge harmonisch klingen wie von einem DJ mit Mixed-In-Key-Workflow — inklusive der fortgeschrittenen Techniken (Energy Boost, Modus-Wechsel), nicht nur "gleiche Camelot-Nummer".

## Bevor du irgendetwas änderst

1. Lies `references/project-map.md` — Key-Detection-Pipeline und die komplette aktuelle Scoring-Tabelle mit Zeilennummern.
2. Prüfe `references/sota.md` (`last_updated` > 30 Tage → Web-Recherche laut Datei, dann aktualisieren).

## Camelot-Regeln, DJ-korrekt (Referenzwissen)

Vom besten zum riskantesten Übergang (A=Moll, B=Dur):

| Übergang | Wirkung | Risiko |
|---|---|---|
| Gleicher Code (8A→8A) | nahtlos | keins |
| ±1 gleicher Modus (8A→9A) | klassischer Flow | keins |
| Relative (8A↔8B) | Stimmungswechsel Moll↔Dur | gering |
| +2 gleicher Modus (8A→10A) | "Energy Boost" | mittel — nur über perkussive Passagen |
| Diagonal (8A→9B / 8A→7B) | Aufhellung/Abdunklung | mittel |
| +7 (= Halbton hoch, 8A→3A) | starker Lift, "Pitch-Riser-Effekt" | hoch — nur kurze Blends |
| -1 (9A→8A) | Entspannung | keins, aber Energie sinkt gefühlt |
| Alles andere | Key Clash | nur Bass-Swap/Cut, keine melodische Überlagerung |

Entscheidend und oft vergessen: **Key-Kompatibilität zählt nur während des Overlaps melodischer Elemente.** Zwei Tracks mit Clash-Keys sind problemlos mixbar, wenn der Übergang über Drum-Passagen läuft. Umgekehrt: Time-Stretch OHNE Key-Lock verschiebt die Tonart (±6 % ≈ ±1 Halbton) — der Camelot-Vergleich muss auf die GESTRETCHTE Tonart angewendet werden, sonst stimmt er genau bei großen BPM-Anpassungen nicht mehr.

## Ist-Zustand (Kurzfassung)

- Key-Detection: `librosa.feature.chroma_stft` (Zeitmittel) → Krumhansl-Schmuckler-Profile mit Cosine-Similarity (Sha'ath/KeyFinder-Stil). Rekordbox-Keys haben Vorrang (confidence 1.0).
- Scoring: 0-100-Tabelle in `playlist._calculate_compatibility_inner` (100/90/85/80/70/65/60/Rest), moduliert von `harmonic_strictness` und Half/Double-Penalty. Gewicht im Gesamt-Score: effektiv ~0.35.
- `key_confidence` existiert, wird aber im Scoring NICHT benutzt — nur als Risk-Note.

## Verbesserungs-Patterns

1. **Confidence-gewichtetes Scoring**: Bei `key_confidence < KEY_CONFIDENCE_UNCERTAIN (0.5)` den harmonic_score Richtung Neutral (≈50) ziehen statt volle 100 oder harte 5 zu vergeben: `score = neutral + (score - neutral) * confidence`. Verhindert, dass eine falsch erkannte Tonart gute Paare zerstört — häufigste Ursache "unharmonischer" Playlists ist falsche Key-Detection, nicht falsches Scoring.
2. **Zweitkandidaten nutzen**: `get_key_with_confidence` liefert `second_note/second_mode`. Bei kleinem `margin` beide Kandidaten scoren und das Maximum (leicht gedämpft) verwenden — robust gegen die typische Verwechslung Relative/Quinte.
3. **Stretch-Key-Kopplung**: Wenn der Renderer Track B um `rate` stretcht (ohne Key-Lock), verschiebt sich der Key um `12*log2(rate)` Halbtöne. Ab |rate-1| > 3 % den Camelot-Code von B entsprechend transponieren, BEVOR gescort wird (`+7` pro Halbton auf dem Rad, Modus bleibt).
4. **Kontext-abhängige Härte**: Clash-Paare nicht global mit 5-15 bestrafen, sondern abhängig vom Übergangsfenster: Liegt der geplante Overlap auf Sections mit niedrigem melodischem Gehalt (hohe `percussive_ratio`, niedrige `avg_mids`), Clash-Malus halbieren. Das erschließt Paarungen, die ein echter DJ problemlos mixt.
5. **Energy-Boost gezielt einsetzen**: In Peak-Time-Strategien +1/+2-Übergänge leicht bevorzugen (Energie-Lift), in Cool-Down -1. Aktuell ist das Scoring richtungslos symmetrisch bei ±1.

## Regeln

- `CAMELOT_MAP`/`REVERSE_CAMELOT_MAP` (models.py/analysis.py) sind die Single Source of Truth für Key↔Camelot — keine Parallel-Tabellen anlegen.
- Rekordbox-Keys (`key_confidence = 1.0`) nie durch librosa-Schätzungen überschreiben.
- Neue Schwellen nach `config.py`; Score-Tabellen-Änderungen IMMER mit Test in `tests/` absichern (es gibt 1200+ Tests, Kompatibilitäts-Scores sind vielfach abgetestet — erst Tests lesen, dann ändern).
- Verifikation: Kleines Script über die Cache-DB — Verteilung der harmonic_scores prüfen (zu viele 5er = Detection-Problem, nicht Musik-Problem) und Stichproben gegen Rekordbox-Keys vergleichen.

## Upgrade-Pfad (optional, siehe sota.md)

Krumhansl-auf-chroma_stft ist solide bis ~75 % Genauigkeit auf EDM. Merkliche Sprünge: CQT-Chroma statt STFT (billig, kein neues Modell), Essentia KeyExtractor (edma-Profil für EDM), oder CNN-Key-Modelle. Reihenfolge: erst CQT + Confidence-Nutzung (Patterns 1-2), dann evtl. Modellwechsel.
