# State of the Art: Key-Detection & Harmonic Mixing

last_updated: 2026-07-24
update_interval_days: 30

## Auto-Update-Anweisung

Wenn `last_updated` älter als `update_interval_days`: Web-Suchen mit "musical key detection state of the art <Jahr>", "key estimation deep learning EDM", "essentia key extractor accuracy", "harmonic mixing algorithm". Datei aktualisieren, `last_updated` setzen, dem User kurz berichten.

## Referenzen (Stand Juli 2026)

- **Krumhansl-Schmuckler + Chroma** (im Projekt): Klassiker; auf EDM begrenzt durch Bass-lastige, perkussive Spektren. Sha'ath (KeyFinder) nutzt Cosine-Variante — so auch HPG.
- **CQT-Chroma / HPCP statt STFT-Chroma**: bekannter, billiger Genauigkeitsgewinn — bessere Tonhöhenauflösung in tiefen Lagen (relevant bei Bass-dominiertem EDM). `librosa.feature.chroma_cqt`, ggf. mit Harmonic-Percussive-Separation (`librosa.effects.hpss`) vorab: Chroma nur auf harmonischem Anteil.
- **Essentia KeyExtractor** mit Profil `edma`/`edmm` (speziell auf Electronic Dance Music kalibriert, Faraldo et al.): starke klassische Alternative, C++/Python.
- **CNN-basierte Key-Modelle** (Korzeniowski & Widmer "keyCNN"-Linie, Nachfolger): SOTA auf Benchmarks; Übersicht/Analyse z. B. arXiv:2505.17259 ("Understanding the Algorithm Behind Audio Key Detection").
- **Kommerzielle Referenz**: Mixed In Key gilt in der DJ-Praxis als Genauigkeits-Referenz; Rekordbox-Keys (im Projekt confidence 1.0) sind gut, aber nicht fehlerfrei — Konfidenz 1.0 ist eine Vereinfachung.
- **DJ AI (Audio Mostly 2025)**: nutzt Embedding-Modelle für Playlist-Alignment inkl. harmonischer Nähe — Richtung "learned compatibility" statt Regel-Tabelle. https://dl.acm.org/doi/full/10.1145/3771594.3771640

## Übertrag auf HPG

Reihenfolge nach Aufwand/Nutzen: (1) key_confidence + second candidate ins Scoring, (2) chroma_cqt + HPSS, (3) Stretch-Key-Kopplung, (4) optional Essentia-edma als alternatives Backend hinter Feature-Flag. Ein Deep-Learning-Modell lohnt erst, wenn (1)-(3) ausgeschöpft sind. Projekt-Constraints beachten: numpy<2, keine schweren neuen Pflicht-Dependencies im Default-Pfad.
