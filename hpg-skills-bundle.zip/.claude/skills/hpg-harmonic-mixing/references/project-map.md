# Code-Landkarte: Harmonic Mixing in HPG V2.0

Stand: 2026-07-24. Zeilennummern können driften — im Zweifel greppen.

## Key-Detection

### `analysis.get_key_with_confidence(chroma_vector)` — analysis.py:87-142
- Input: Zeitmittel von `librosa.feature.chroma_stft` (analysis.py:1319-1320)
- `MAJOR_PROFILE`/`MINOR_PROFILE` (Krumhansl-Schmuckler, analysis.py:81-82), **Cosine-Similarity** statt Pearson (Sha'ath/KeyFinder-Begründung im Docstring)
- 24 Kandidaten; Rückgabe `(note, mode, strength, margin, second_note, second_mode)`; `margin = (max-max2)/|max|`

### `analysis.key_confidence_score` — analysis.py:151-182
- strength ≥ 0.6 UND margin ≥ 0.05 → ≥ 0.6
- Zweitkandidat ist Camelot-Nachbar (Relative oder Quinte) → ≥ 0.5
- sonst ≤ 0.4
- `config.KEY_CONFIDENCE_UNCERTAIN = 0.5` (Risk-Schwelle)

### Rekordbox-Pfad
`key_confidence = 1.0`, Key via `REVERSE_CAMelot_MAP` → analysis.py:35, 1147-1156. Hat Vorrang.

### Mapping
`models.CAMELOT_MAP` (models.py:9-18), `models.key_to_camelot` (models.py:215-218). Track-Felder: `keyNote`, `keyMode`, `camelotCode`, `key_confidence`.

## Scoring

### `playlist._calculate_compatibility_inner` — playlist.py:307-385 (Skala 0-100)

| Regel | Score | Zeile |
|---|---|---|
| BPM-Diff > bpm_tolerance | 0 (Hard Gate) | 324-325 |
| Kein Camelot-Code | 10 (×0.85 bei half/double) | 326-331 |
| Gleicher Key | 100 | 343-344 |
| Gleiche Nummer A→B (Moll→Dur) | 90 | 349-350 |
| Gleiche Nummer B→A | 85 | 351 |
| ±1 gleicher Modus | 80 | 357-359 |
| +4-Technik gleicher Modus | 70 × loose_factor | 368-371 |
| +7-Technik gleicher Modus | 65 × loose_factor | 373-377 |
| Diagonal (±1 + Moduswechsel) | 60 × loose_factor | 380-382 |
| Rest | max(5, 15 - strictness) | 385 |

- `penalty = BPM_HALF_DOUBLE_PENALTY (0.85)` wenn relation != "direct"
- `loose_factor = max(0.4, min(1.2, 1.0 - (strictness-7)*0.08))`; `harmonic_strictness` Default 7; `allow_experimental` Default True
- HINWEIS: "+2 Energy Boost" (8A→10A) fehlt in der Tabelle komplett — fällt in "Rest".

### Einbettung
- `calculate_enhanced_compatibility` (playlist.py:210-290): `overall = (rem*0.44)*harmonic/100 + (rem*0.28)*bpm_smooth + (rem*0.28)*energy_flow + genre_weight*genre_comp + ai_bonus(≤0.14)`; `genre_weight` 0.2 mit DJ-Brain-Genres, sonst 0.1; Hard Gate bei BPM-Diff. Effektiv: Harmonic 0.352 / BPM 0.224 / Energy 0.224 / Genre 0.20.
- `calculate_playlist_quality` (1338-1405): harmonic_flow Gewicht **0.5**, energy 0.25, bpm 0.25.
- `dj_brain._key_advice` (816-864): Text; Camelot-Distanz `min(|a-b|, 12-|a-b|)`; 4/5 gleicher Modus = "+4/+7 experimentell"; sonst "Key-Clash — nur Bass Swap".
- `dj_brain._assess_transition_risks` (1137-1146): Warnung ab Distanz > 2; `key_confidence < 0.5` → eigene Risk-Note.
- `key_confidence` fließt NICHT ins Scoring ein (nur Risk-Text).

## Bekannte Lücken

- Kein Confidence-Weighting im Score (falsche Keys wirken mit voller Härte)
- second_note/second_mode ungenutzt
- Keine Stretch-Key-Kopplung (Renderer stretcht bis ±15 % ohne Key-Lock → bis ~2.4 Halbtöne Verschiebung, Scoring merkt nichts)
- +2 (Energy Boost) fehlt in der Tabelle
- Clash-Malus kontextlos (ignoriert percussive_ratio/avg_mids des Übergangsfensters)
